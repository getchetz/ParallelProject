package com.cg.entity;

public class BankAccount {
private int cusAccNumber;
private String accType;
private int accPin;
private int accBalance;
public BankAccount() {
	super();
	// TODO Auto-generated constructor stub
}
public BankAccount(int cusAccountNumber, String accType, int accPin, int accBalance) {
	super();
	this.cusAccNumber = cusAccountNumber;
	this.accType = accType;
	this.accPin = accPin;
	this.accBalance = accBalance;
}
public Integer getCusAccountNumber() {
	return cusAccNumber;
}
public void setCusAccountNumber(int cusAccountNumber) {
	this.cusAccNumber = cusAccountNumber;
}
public String getAccType() {
	return accType;
}
public void setAccType(String accType) {
	this.accType = accType;
}
public int getAccPin() {
	return accPin;
}
public void setAccPin(int accPin) {
	this.accPin = accPin;
}
public double getAccBalance() {
	return accBalance;
}
public void setAccBalance(int accBalance) {
	this.accBalance = accBalance;
}
@Override
public String toString() {
	return "BankAccount [cusAccountNumber=" + cusAccNumber + ", accType=" + accType + ", accPin=" + accPin
			+ ", accBalance=" + accBalance + "]";
}

}
