package com.cg.entity;

public class Customer {
private String cusName;
private String cusAddress;
private int cusAccNumber;
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String cusName, String cusAddress, int cusAccNumber) {
	super();
	this.cusName = cusName;
	this.cusAddress = cusAddress;
	this.cusAccNumber = cusAccNumber;
}
public String getCusName() {
	return cusName;
}
public void setCusName(String cusName) {
	this.cusName = cusName;
}
public String getCusAddress() {
	return cusAddress;
}
public void setCusAddress(String cusAddress) {
	this.cusAddress = cusAddress;
}
public Integer getCusAccNumber() {
	return cusAccNumber;
}
public void setCusAccNumber(int cusAccNumber) {
	this.cusAccNumber = cusAccNumber;
}
@Override
public String toString() {
	return "Customer [cusName=" + cusName + ", cusAddress=" + cusAddress + ", cusAccNumber=" + cusAccNumber + "]";
}

}
