package com.cg.dao;

import java.util.HashMap;

import com.cg.entity.BankAccount;
import com.cg.entity.Customer;
import com.cg.exception.CustomerAccountException;
import com.cg.util.Collection;

public class CustomerBankDaoImp implements CustomerBankDao {
Collection col=new Collection();
	


	@Override
	public BankAccount getAccBalance(int cusAccNumber) throws CustomerAccountException {
		BankAccount ba=col.getAccBalance(cusAccNumber);
		return ba;
	}



	@Override
	public int createAccount(BankAccount bac,Customer ca) throws CustomerAccountException {
		int ban=col.createAccount(bac,ca);
		return ban;
	}



	@Override
	public BankAccount deposite(int cusAccNumber, int depamount) throws CustomerAccountException {
		BankAccount ba=col.deposite(cusAccNumber, depamount);
		return ba;
	}



	@Override
	public BankAccount withdraw(int cusAccNumber, int withamm) throws CustomerAccountException {
		BankAccount ba=col.withdraw(cusAccNumber,withamm);
		return ba;
	}



	@Override
	public BankAccount fundTransfer(int cusAccNumber, int cusAccNumber1, int trfamm) throws CustomerAccountException {
		BankAccount ba=col.fundTransfer(cusAccNumber, cusAccNumber1, trfamm);
		return ba;
	}



	@Override
	public HashMap<Integer, BankAccount> fetchAllDetails() throws CustomerAccountException {
		HashMap<Integer,BankAccount> hm=col.fetchAllDetails();
		return hm;
	}



	



	

}
