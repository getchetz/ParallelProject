package com.cg.ui;

import java.util.HashMap;
import java.util.Scanner;

import javax.naming.ldap.SortKey;

import com.cg.entity.BankAccount;
import com.cg.entity.Customer;
import com.cg.exception.CustomerAccountException;
import com.cg.service.CustomerBankServiceImp;

public class BankAccountMain {
	static int choice;
	static int cusAccNumber;
	static int depamount;
	static int withamm;
	static int cusAccNumber1;
	static int trfamm;
	static CustomerBankServiceImp cbsi=new CustomerBankServiceImp();
public static void main(String[] args) throws CustomerAccountException {
	System.out.println("welcome to capgemini banking services");
	Scanner sc=new Scanner(System.in);
	
	do {
	System.out.println("select your option");
	System.out.println("1. Creat an account");
	System.out.println("2.Display balance");
	System.out.println("3.Deposite amount");
	System.out.println("4.Withdraw  amount");
	System.out.println("5.Transfer  amount");
	choice=sc.nextInt();
	
	
	switch(choice)
	{
	case 1:
		createAccount();
		break;
		
	case 2:
		getaccBalance();
		
	case 3:
		
		deposit(cusAccNumber,depamount);
	break;
	case 4:
		withdraw(cusAccNumber,withamm);
	case 5:
		fundTransfer( cusAccNumber, cusAccNumber1, trfamm);
		
	System.exit(0);
	}
	}while(choice<=3);
}

private static void fundTransfer(int cusAccNumber,int cusAccNumber1,int trfamm) throws CustomerAccountException {
	Scanner sc =new Scanner(System.in);
	System.out.println("enter account number");
	 cusAccNumber=sc.nextInt();
	System.out.println("enter account pin");
	int accPin=sc.nextInt();
	
	BankAccount ba=cbsi.getAccBalance(cusAccNumber);//cbsi.fundTransfer(cusAccNumber, cusAccNumber1, trfamm);
	 HashMap <Integer,BankAccount>hm=cbsi.fetchAllDetails();
	if(cusAccNumber==ba.getCusAccountNumber() && accPin==ba.getAccPin())
	{
	
	System.out.println("Enter account benificiary account number");
	 cusAccNumber1=sc.nextInt();
	
	if(hm.containsKey(cusAccNumber1)) {
		System.out.println("enter amount to transfer");
		trfamm=sc.nextInt();
		ba=cbsi.fundTransfer(cusAccNumber, cusAccNumber1, trfamm);
		
		if(trfamm<=ba.getAccBalance()) {
			
			System.out.println("Transfer of amount is successful");
		}
		else {
			System.out.println("we are unable to carry operation due to insuffecient funds");
		}
	
	}
	else {
		System.out.println("enter valid benifitiory number");
	}
	
	
	}else
	{
		System.out.println("enter valid credientials ");
	}
	
}

private static void withdraw(int cusAccNumber,int withamm ) throws CustomerAccountException {
	Scanner sc =new Scanner(System.in);
	System.out.println("enter account number");
	cusAccNumber=sc.nextInt();
	System.out.println("enter account pin");
	int accPin=sc.nextInt();
	BankAccount ba=cbsi.getAccBalance(cusAccNumber);
	
	if(cusAccNumber==ba.getCusAccountNumber() && accPin==ba.getAccPin())
	{
		System.out.println(ba.getAccBalance());
		System.out.println("enter amount to Withdraw");
		
		Scanner sc1 =new Scanner(System.in);
		 withamm=sc1.nextInt();
		if(withamm<=ba.getAccBalance()) {
			System.out.println("Please collect your cash");
			withamm=(int) (ba.getAccBalance()-withamm);
			System.out.println("remaining bal in account is"+(withamm));
		}
		else {
			System.out.println("We are unable to process your request");
		}
	}
	else {
		System.out.println("Please enter valid credentials");
	}
	
}

private static void deposit(int cusAccNumber,int depamount) throws CustomerAccountException {
	Scanner sc =new Scanner(System.in);
	System.out.println("enter account number");
	 cusAccNumber=sc.nextInt();
	BankAccount ba=cbsi.deposite(cusAccNumber, depamount);
	
	if(cusAccNumber==ba.getCusAccountNumber())
	{
	System.out.println("enter amount to deposite");
	
	Scanner sc1 =new Scanner(System.in);
	depamount=sc1.nextInt();
	depamount=(int) (depamount+ba.getAccBalance());
	System.out.println("Deposit success curreSnt balance is"+(depamount));
	
	}       
	else
	{
		System.out.println("please check ur details");
	}

}

private static void getaccBalance() throws CustomerAccountException {
	Scanner sc =new Scanner(System.in);
	System.out.println("enter account number");
	int cusAccNumber=sc.nextInt();
	System.out.println("enter account pin");
	int accPin=sc.nextInt();
	BankAccount ba=cbsi.getAccBalance(cusAccNumber);
	if(cusAccNumber==ba.getCusAccountNumber() && accPin==ba.getAccPin())
	{
	System.out.println(ba.getAccBalance());
	}
	else {
		System.out.println("Enter valid pin and account number");
	}
	
	
}
private static void createAccount() throws CustomerAccountException {   //account creation
	Scanner sc=new Scanner(System.in);
	System.out.println("Thank you for choosing our bank");
	
	System.out.println("Please enter Account holder name");
	String cusName=sc.nextLine();
	
	if(cbsi.validatename(cusName)==true) { //validation for name start
	
		System.out.println("Please enter Your Address");
	
		String cusAddress=sc.nextLine();
	
		if(cbsi.validateAddress(cusAddress)==true) { //validation for address start
	System.out.println("Please choose type of account");
	
	System.out.println("Type 1 for Savings account  "); //Selection of type of account
	System.out.println("Type 2 for Current account  ");
	
	int choice=sc.nextInt();
	if(cbsi.validateChoice(choice)==true) {
	int max=9999;
	int min=1;
	int range=max-min+1;
	int accPin=(int)(Math.random()*range)+min;
	int max1=999999999;
	int min1=1;
	int range1=max1-min1+1;
	int cusAccNumber=(int)(Math.random()*range1)+min1;
	System.out.println("deposite some amount in your account");
	int accBalance=sc.nextInt();
	
	 String accType;
	 System.out.println("Balance deposited in account is Rs"+" "+accBalance);
	 System.out.println("Generated Account pin is :"+accPin);
		System.out.println("Generated Account number is:"+cusAccNumber);
		System.out.println("Please note your Account number");
		
		Customer ca=new Customer(cusName,cusAddress,cusAccNumber);
		
	
	if(choice==1) {
		
	    accType="Savings";
		System.out.println("Account type selected is:"+accType);
		BankAccount bac=new BankAccount(cusAccNumber,accType,accPin,accBalance);
	cbsi.createAccount(bac,ca);
		
	}
	if(choice==2) {
		accType="Current";
		System.out.println("Account type selected is:"+accType);
		
	
		BankAccount bac=new BankAccount(cusAccNumber,accType,accPin,accBalance);
		cbsi.createAccount(bac,ca);
		
	
	}
	
	}
	else {
		System.out.println("enter valid choice");
	}
		}
	else
	{
		System.out.println("enter valid Address");
	}
	}
	else
	{
		System.out.println("enter valid name");
	}
		
	}
}


