package com.cg.util;

import java.util.HashMap;

import com.cg.entity.BankAccount;
import com.cg.entity.Customer;

public class Collection {
	static BankAccount bac=  new BankAccount();
	public static HashMap<Integer,Customer> cus=new HashMap<Integer,Customer>();
	static {
		cus.put(1231113112,new Customer("krishna","hyderabad",1231113112));
		cus.put(1231113221,new Customer("sai","hyderabad",1231113221));
		cus.put(1231113423,new Customer("krishna","hyderabad",1231113423));
	}
	public static HashMap<Integer,BankAccount> ba=new HashMap<Integer,BankAccount>();
	static {
		ba.put(1231113112,new BankAccount(1231113112,"savings",1211,5000));
		ba.put(1231113221,new BankAccount(1231113221,"savings",1222,1000));
		ba.put(1231113423,new BankAccount(1231113423,"savings",1214,5000));
	}
	public  int createAccount(BankAccount bac,Customer ca) {
		
		ba.put(bac.getCusAccountNumber(),bac);
		cus.put(bac.getCusAccountNumber(), ca);
		//System.out.println(cus);
		return bac.getCusAccountNumber();
		
		
	}
	public static BankAccount getAccBalance(int cusAccNumber)
	{
		//bac.getAccBalance();
		return ba.get(cusAccNumber);
	}
		public static BankAccount deposite(int cusAccNumber,int depamount) {
			BankAccount bac=ba.get(cusAccNumber);
			return bac=ba.get(cusAccNumber);
			
			
		}
		public static BankAccount withdraw(int cusAccNumber,int withamm) {
			BankAccount bac=ba.get(cusAccNumber);
			return bac=ba.get(cusAccNumber);
			
			
		}
		public static BankAccount fundTransfer(int cusAccNumber,int cusAccNumber1,int trfamm) {
			BankAccount bac=ba.get(cusAccNumber);
			BankAccount bac1=ba.get(cusAccNumber1);
			 
			trfamm=(int) (bac1.getAccBalance()+trfamm);
			bac1.setAccBalance(trfamm);
			
			trfamm=(int) (bac.getAccBalance()-trfamm);
			 bac.setAccBalance(trfamm);
			
			 return bac1=ba.get(cusAccNumber);
			
		}
public static HashMap<Integer,BankAccount> fetchAllDetails(){
	return ba;
}
}



